export default[
    {
        link:'https://buy.stripe.com/test_9AQ4jI8fffk75igcMN',
        price:7.99,
        priceId:'price_1PUNYmSISOkj08jR30L0UpyY',
        duration:'Monthly'
    },
    {
        link:'https://buy.stripe.com/test_eVabMa8fffk78us000',
        price:49.00,
        priceId:'price_1PUNZQSISOkj08jRFQkKuzXi',
        duration:'Yearly'
    }
]